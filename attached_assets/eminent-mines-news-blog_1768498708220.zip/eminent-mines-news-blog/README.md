# EMRL News Blog - Eminent Mines Resources Limited

A modern, responsive news blog template designed for Eminent Mines Resources Limited (EMRL) to showcase company news, sustainability initiatives, investor relations updates, and technological advancements in Nigeria's mining sector.

## Table of Contents

1. [Project Overview](#project-overview)
2. [File Structure](#file-structure)
3. [Quick Start](#quick-start)
4. [Customization Guide](#customization-guide)
   - [Colors and Branding](#colors-and-branding)
   - [Typography](#typography)
   - [Images](#images)
5. [Managing Content](#managing-content)
   - [Adding New Articles](#adding-new-articles)
   - [Updating Existing Articles](#updating-existing-articles)
   - [Category Management](#category-management)
6. [Features](#features)
7. [Browser Support](#browser-support)
8. [Deployment](#deployment)
9. [License](#license)

## Project Overview

This news blog is built with modern web technologies and follows best practices for performance, accessibility, and user experience. The template includes:

- **Responsive Design**: Works seamlessly across desktop, tablet, and mobile devices
- **Category Filtering**: Users can filter articles by Industry News, Sustainability, Investor Relations, and Technology
- **Featured Article Section**: Highlight your most important news story
- **Newsletter Integration**: Email subscription form for audience engagement
- **Modern UI/UX**: Clean, professional design with smooth animations
- **SEO Optimized**: Semantic HTML structure for better search engine visibility

## File Structure

```
eminent-mines-news-blog/
├── index.html          # Main HTML structure
├── styles.css          # Complete styling with CSS variables
├── script.js           # Interactive functionality
├── README.md           # This file
└── images/
    ├── lithium-hero.svg        # Featured article image
    ├── sustainability.svg      # Community water project
    ├── investment-forum.svg    # Investment forum
    ├── technology.svg          # Laboratory technology
    ├── community-training.svg  # Training programs
    ├── exploration.svg         # Geological exploration
    └── environmental.svg       # Environmental restoration
```

## Quick Start

1. **Open the project**: Navigate to the `eminent-mines-news-blog` folder
2. **View locally**: Open `index.html` in any modern web browser
3. **Customize**: Edit the HTML, CSS, and images to match your brand

No build tools or server required - this is a pure static website that works out of the box.

## Customization Guide

### Colors and Branding

The color scheme is defined in CSS variables at the top of `styles.css`. Modify these values to match EMRL's brand identity:

```css
:root {
    --primary-gold: #C4A052;       /* Main brand color */
    --primary-gold-light: #D4B872; /* Hover state */
    --primary-gold-dark: #A88A3E;  /* Active state */
    --text-dark: #1A1A1A;          /* Primary text */
    --text-medium: #4A4A4A;        /* Secondary text */
    --text-light: #6B6B6B;         /* Muted text */
    --bg-white: #FFFFFF;           /* Background */
    --bg-light: #F8F8F8;           /* Secondary background */
}
```

**Category Colors**:
- Industry News: `#C4A052` (Gold)
- Sustainability: `#27AE60` (Green)
- Investor Relations: `#3498DB` (Blue)
- Technology: `#9B59B6` (Purple)

### Typography

The template uses a font stack system. To use custom fonts:

1. Import fonts in `styles.css`:
```css
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600&family=Inter:wght@400;500;600&display=swap');
```

2. Update the CSS variables:
```css
--font-serif: 'Playfair Display', Georgia, serif;
--font-sans: 'Inter', -apple-system, sans-serif;
```

3. Apply fonts throughout:
```css
h1, h2, h3 {
    font-family: var(--font-serif);
}

body {
    font-family: var(--font-sans);
}
```

### Images

#### Replacing Placeholder Images

The project includes SVG placeholder images in the `images/` directory. To replace with real photographs:

1. **Prepare your images**:
   - Recommended dimensions:
     - Featured article: 800x450 pixels (16:9 ratio)
     - Standard cards: 800x450 pixels (16:9 ratio)
   - Formats: JPG, PNG, or WebP
   - File sizes: Keep under 200KB for optimal performance

2. **Naming convention**:
   - Use descriptive names: `lithium-mining.jpg`, `community-event.jpg`
   - Replace the existing SVG files or add new ones

3. **Update HTML**:
```html
<img src="images/your-image.jpg" alt="Descriptive alt text">
```

**Photography Tips for Mining Industry**:
- Use high-quality images showing mining operations, community engagement, and technology
- Ensure proper lighting and composition
- Include people shots to add human interest
- Capture environmental and sustainability initiatives
- Maintain professional, authentic aesthetic

## Managing Content

### Adding New Articles

To add a new article to the blog, copy and modify this template:

```html
<article class="news-card">
    <div class="card-image">
        <img src="images/your-new-image.svg" alt="Article image description">
        <span class="category-tag [category]">Category Name</span>
    </div>
    <div class="card-content">
        <div class="article-meta">
            <span class="date">Month DD, YYYY</span>
        </div>
        <h3>Article Headline</h3>
        <p>Brief description or excerpt of the article (2-3 sentences maximum).</p>
        <div class="card-footer">
            <span class="author">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                    <circle cx="12" cy="7" r="4"/>
                </svg>
                Author Name
            </span>
            <a href="#" class="read-more-link">
                Read More
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M5 12h14M12 5l7 7-7 7"/>
                </svg>
            </a>
        </div>
    </div>
</article>
```

**Category Options**:
- `industry` - Industry News
- `sustainability` - Sustainability
- `investor` - Investor Relations
- `technology` - Technology

### Updating Existing Articles

Edit the HTML directly in `index.html`:
- Modify headline text in `<h2>` or `<h3>` tags
- Update article content in `<p>` tags
- Change dates in `<span class="date">` elements
- Update author information in `<span class="author">`

### Category Management

To add new filter categories:

1. **Add filter button** in the filter section:
```html
<button class="filter-btn" data-filter="new-category">New Category</button>
```

2. **Update JavaScript filter logic** in `script.js`:
```javascript
function filterCards(filter, cards) {
    // Add condition for new category
    if (filter === 'new-category' ||
        card.querySelector(`.category-tag.new-category`)) {
        // Show card
    } else {
        // Hide card
    }
}
```

## Features

### Interactive Elements

1. **Category Filtering**: Click filter buttons to show articles by category with smooth animations
2. **Hover Effects**: Cards lift and show shadow on hover for better interactivity
3. **Newsletter Subscription**: Email validation and subscription feedback
4. **Load More**: Expandable article list with loading animation
5. **Notifications**: User feedback system for actions

### Responsive Design Breakpoints

- **Desktop**: 1024px and above (3-column grid)
- **Tablet**: 768px to 1023px (2-column grid)
- **Mobile**: below 768px (single column)

### Accessibility Features

- Semantic HTML structure
- Proper heading hierarchy (h1 → h2 → h3)
- Alt text for all images
- Keyboard-navigable interface
- Sufficient color contrast ratios
- Focus states for interactive elements

### Performance Optimizations

- CSS animations use hardware acceleration
- Minimal JavaScript with no external dependencies
- SVG images are lightweight and scalable
- No external font dependencies (uses system fonts)

## Browser Support

- Chrome (latest 2 versions)
- Firefox (latest 2 versions)
- Safari (latest 2 versions)
- Edge (latest 2 versions)
- Opera (latest 2 versions)

Internet Explorer 11 is not supported.

## Deployment

### Option 1: Static Hosting

Upload all files to any static hosting service:

- **Netlify**: Drag and drop the project folder
- **Vercel**: Connect your Git repository
- **GitHub Pages**: Push to a gh-pages branch
- **AWS S3**: Configure as static website
- **Traditional Hosting**: Upload via FTP/SFTP

### Option 2: CMS Integration

For dynamic content management:

1. **WordPress**: Convert HTML to custom theme or use as static homepage
2. **Contentful/Strapi**: Connect to headless CMS for article management
3. **Jekyll/Hugo**: Use as static site generator template

### SEO Recommendations

For better search engine visibility:

1. Update page title and meta description:
```html
<title>News & Insights | Eminent Mines Resources Limited</title>
<meta name="description" content="Stay updated with EMRL's latest developments in sustainable mining, community initiatives, and technological innovations.">
```

2. Add Open Graph tags for social sharing:
```html
<meta property="og:title" content="Nigeria's Lithium Revolution: EMRL Leads the Way">
<meta property="og:description" content="The global demand for clean energy has placed Nigeria's lithium deposits in the spotlight...">
<meta property="og:image" content="images/lithium-hero.jpg">
```

3. Create a sitemap.xml for search engines

## Content Strategy Recommendations

### Article Categories

**Industry News**:
- Exploration discoveries
- Production updates
- Industry partnerships
- Regulatory developments
- Market insights

**Sustainability**:
- Environmental initiatives
- Community development programs
- Training and education
- Reclamation projects
- Safety achievements

**Investor Relations**:
- Financial announcements
- Investment forums
- Partnership news
- Growth strategies
- Corporate governance

**Technology**:
- Equipment upgrades
- Innovation projects
- Quality assurance
- Research partnerships
- Digital transformation

### Publishing Schedule

- **Weekly**: At least one new article
- **Monthly**: Feature story with in-depth coverage
- **Quarterly**: Comprehensive industry report

### Content Length Guidelines

- **Short**: 300-500 words for quick updates
- **Medium**: 500-1000 words for standard news
- **Long**: 1000-2000 words for feature stories

## License

This template is provided for use by Eminent Mines Resources Limited. All rights reserved.

For questions or support, contact the development team.

---

**Eminent Mines Resources Limited** - Leading Nigeria's mining transformation through sustainable practices and innovation.
